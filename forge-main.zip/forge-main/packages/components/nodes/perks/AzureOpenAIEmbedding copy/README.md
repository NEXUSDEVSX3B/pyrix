# Azure OpenAI Embedding Model

Azure OpenAI Embedding Model integration for AgentForge

## 🌱 Env Variables

| Variable                     | Description                                                                                     | Type                                             | Default                             |
| ---------------------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------ | ----------------------------------- |
| AZURE_OPENAI_API_KEY    | Default `credential.azureOpenAIApiKey` for Azure OpenAI Model                                            | String                                                                    |            |
| AZURE_OPENAI_API_INSTANCE_NAME    | Default `credential.azureOpenAIApiInstanceName` for Azure OpenAI Model                                            | String                                                                    |            |
| AZURE_OPENAI_API_EMBEDDINGS_DEPLOYMENT_NAME    | Default `credential.azureOpenAIApiDeploymentName` for Azure OpenAI Model                                            | String                                                                    |            |
| AZURE_OPENAI_API_VERSION    | Default `credential.azureOpenAIApiVersion` for Azure OpenAI Model                                            | String                                                                    |            |

## License

Source code in this repository is made available under the [Apache License Version 2.0](https://github.com/AgentForge-SKAIAgentForge/blob/master/LICENSE.md).